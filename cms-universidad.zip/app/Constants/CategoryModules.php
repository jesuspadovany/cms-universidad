<?php

namespace App\Constants;

class CategoryModules
{
    use HasConstants;

    public const SCHEDULE = 'agenda';
    public const COURSES = 'cursos';
    public const LIBRARY = 'biblioteca';
}
