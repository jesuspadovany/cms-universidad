<nav class="flex items-center p-3 bg-primary text-white shadow-md">
	<a href="<?php echo e(route('home.index')); ?>" class="text-xl">el Rojas</a>

	<div class="flex items-center ml-auto">
		<div>
            <a href="<?php echo e(route('schedule.index')); ?>" class="mr-2 font-semibold">Agenda</a>
            <a href="<?php echo e(route('courses.index')); ?>" class="mr-2 font-semibold">Cursos</a>
            <a href="<?php echo e(route('library.index')); ?>" class="font-semibold">Biblioteca</a>
        </div>

		<div class="mx-4">
			<button type="button" class="focus:outline-none">
				<i class="fa fa-search curso"></i>
			</button>
		</div>

		<button type="button">
			<i class="fa fa-bars fa-lg"></i>
		</button>
	</div>
</nav>
<?php /**PATH /home/ale/laravel-projects/cms-universidad/resources/views/partials/navbar.blade.php ENDPATH**/ ?>