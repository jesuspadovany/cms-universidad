<?php $__env->startSection('section-title', 'Slider Principal'); ?>

<?php $__env->startSection('content'); ?>
<section class="p-4">
    <div class="p-6 bg-red-400 rounded <?php echo e($errors->any() ? '' : 'hidden'); ?>">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?> <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <create-slide-form
        class="p-6"
        :csrf-token='<?php echo json_encode(csrf_token(), 15, 512) ?>'
        :slides='<?php echo json_encode($slides, 15, 512) ?>'
    ></create-slide-form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ale/laravel-projects/cms-universidad/resources/views/admin/slider/create.blade.php ENDPATH**/ ?>