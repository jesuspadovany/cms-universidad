<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Universidad de Buenos Aires</title>

	
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&display=swap" rel="stylesheet">

	
	<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">

	
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
	<div class="flex" id="app">
		
		<?php echo $__env->make('admin.partials.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		
		<section class="w-full min-h-screen">
			
			<section class="flex items-center h-16 p-4 bg-primary text-white">
				<button type="button" class="focus:outline-none">
					<i class="fa fa-bars fa-lg"></i>
				</button>

				<h2 class="px-4 leading-none font-semibold text-3xl"><?php echo $__env->yieldContent('section-title'); ?></h2>

				<a href="#" class="ml-auto p-2 hover:bg-primary-darker rounded text-center text-sm">
					<div>
						<i class="fa fa-sign-out-alt fa-lg"></i>
					</div>
					Cerrar sesión
				</a>
			</section>

			<main>
				<?php echo $__env->yieldContent('content'); ?>
			</main>
		</section>
	</div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/ale/laravel-projects/cms-universidad/resources/views/admin/layouts/master.blade.php ENDPATH**/ ?>