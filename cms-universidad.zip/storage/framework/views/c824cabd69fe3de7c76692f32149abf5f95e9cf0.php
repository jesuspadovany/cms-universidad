<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Universidad de Buenos Aires</title>

	
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&display=swap" rel="stylesheet">

	
	<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">

	
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
	<div id="app">
        
        <the-navbar></the-navbar>

        
        <div class="hero-section-h relative bg-blue-500">
            <?php echo $__env->yieldContent('header'); ?>
        </div>

        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <footer class="footer text-white">
            <div class="container mx-auto p-24">
                <div class="flex">
                    <div class="w-1/2">
                        <h2 class="mb-4 font-semibold text-5xl text-primary">UBA</h2>
                        <p class="text-2xl">
                            Secretaría de Relaciones <br>
                            Institucionales, Culturales <br>
                            y Comunicación
                        </p>
                    </div>
                    <div class="w-1/2">
                        <h2 class="mb-4 text-5xl text-primary">Centro Cultural Rojas</h2>
                        <p class="text-2xl">
                            C104AAF / CABA Argentina <br>
                            +54 11 4953-5405
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/ale/laravel-projects/cms-universidad/resources/views/layouts/master.blade.php ENDPATH**/ ?>