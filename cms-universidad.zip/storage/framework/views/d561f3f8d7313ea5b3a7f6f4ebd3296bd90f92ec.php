<?php $__env->startSection('content'); ?>
<section class="container mx-auto px-4 py-6">
     <?php if (isset($component)) { $__componentOriginal980043edc96762008938c06406884f217c1f804e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SectionTitle::class, ['title' => 'Biblioteca','icon' => 'fas fa-book']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-6 text-primary']); ?>
        <a href="#" class="px-3 py-2 rounded-lg border-2 border-primary font-semibold">
            filtrar por
            <i class="fas fa-caret-down"></i>
        </a>
     <?php if (isset($__componentOriginal980043edc96762008938c06406884f217c1f804e)): ?>
<?php $component = $__componentOriginal980043edc96762008938c06406884f217c1f804e; ?>
<?php unset($__componentOriginal980043edc96762008938c06406884f217c1f804e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    
    <div class="grid grid-cols-2 gap-6 mb-6">
        <?php $__currentLoopData = range(1, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-300 rounded-lg overflow-hidden">
                <div class="flex h-40">
                    <div class="flex-shrink-0 flex w-32 bg-gray-400">
                        <img src="https://via.placeholder.com/65x100" class="inline h-32 m-auto shadow-md">
                    </div>
                    <div class="p-4 w-full">
                        <h3 class="text-xl mb-2">Somos nuestro cerebro</h3>

                        <p>
                            Capo sinceramente supiera lo que dice aquí lo escribiria pero no tengo ni la mejor idea,
                            si sabes lo que dice por favor escribemelo
                        </p>
                    </div>
                </div>
                <div class="flex px-3 py-2 bg-primary font-semibold text-white">
                    <span>Gratis</span>
                    <a href="#" class="ml-auto">Leer</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="text-center">
        <a href="#" class="inline-block px-16 py-2 bg-primary rounded-md font-semibold text-white">
            Más...
        </a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ale/laravel-projects/cms-universidad/resources/views/library/index.blade.php ENDPATH**/ ?>