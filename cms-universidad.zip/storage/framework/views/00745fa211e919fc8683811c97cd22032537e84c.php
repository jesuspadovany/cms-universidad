<div <?php echo e($attributes->merge(['class' => 'flex items-center'])); ?>>
	<h2 class="text-5xl">
		<?php if($icon): ?>
			<i class="<?php echo e($icon); ?>"></i>
		<?php endif; ?>

		<?php echo e($title); ?>

	</h2>

	<div class="ml-auto">
		<?php echo e($slot); ?>

	</div>
</div><?php /**PATH /home/ale/laravel-projects/cms-universidad/resources/views/components/section-title.blade.php ENDPATH**/ ?>