import './bootstrap';
import Vue from 'vue';
import VueCompositionApi from '@vue/composition-api';

Vue.use(VueCompositionApi);

new Vue({
  el: '#app'
});
